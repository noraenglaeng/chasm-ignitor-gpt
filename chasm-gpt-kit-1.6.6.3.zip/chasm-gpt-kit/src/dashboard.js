'use strict';
const el=id=>document.getElementById(id);
let pair=new URLSearchParams(location.hash.slice(1)).get('pair')||sessionStorage.getItem('local-gpt-pair-v1')||'';
if(location.hash)history.replaceState(null,'',location.pathname);
let state=null,busy=false;el('pair').value=pair;
function message(text,error=false){el('status').textContent=text;el('status').classList.toggle('error',error);}
function parsePair(value){
  const raw=value.trim();
  if(!raw.startsWith('http'))return raw;
  const url=new URL(raw);if(url.origin!==location.origin||url.hostname!=='127.0.0.1')throw Error('현재 관리 화면과 같은 주소의 코드를 넣으세요.');
  return new URLSearchParams(url.hash.slice(1)).get('pair')||'';
}
async function api(route,body){
  if(!pair)throw Error('Termux가 표시한 연결 코드를 먼저 넣으세요.');
  const response=await fetch(route,{method:body===undefined?'GET':'POST',headers:{Authorization:'Bearer '+pair,'Content-Type':'application/json'},...(body===undefined?{}:{body:JSON.stringify(body)})});
  const data=await response.json();if(!response.ok)throw Error(data.message||data.code||'연결에 실패했습니다.');return data;
}
async function refresh(){
  state=await api('/api/status');
  for(const key of ['max_chars','max_calls_5h','max_calls_24h'])el(key).value=state.settings[key];
  el('pause').textContent=state.settings.paused?'새 요청 재개':'새 요청 일시정지';
  message('구독 로그인: '+(state.connected?'완료':'연결 필요')+' · 서버 일시정지: '+(state.settings.paused?'예':'아니요')+'\n최근 5시간 AI 호출 '+state.calls.five_hours+'회 · 최근 24시간 '+state.calls.last_24_hours+'회');
  el('jobs').replaceChildren();
  if(!state.recent.length){el('jobs').textContent='아직 요청한 작업이 없습니다. 원본 확장 프로그램을 이 서버에 연결한 뒤 사용하세요.';return;}
  for(const job of state.recent){
    const details=document.createElement('details'),title=document.createElement('summary'),output=document.createElement('pre');
    title.textContent=job.status+' · '+job.request_id.slice(0,12);output.textContent='펼치면 저장된 결과를 조회합니다.';
    details.append(title,output);let loaded=false;
    details.addEventListener('toggle',()=>{if(details.open&&!loaded){loaded=true;api('/api/jobs/'+job.request_id).then(data=>{
      output.textContent=JSON.stringify(data,null,2);
      if(data.status==='blocked_budget'){
        const resume=document.createElement('button');resume.textContent='로컬 설정 확인 후 이 작업 재개';
        resume.addEventListener('click',()=>run(async()=>{await api('/api/jobs/'+job.request_id+'/resume',{});await refresh();}));details.append(resume);
      }
    }).catch(error=>{loaded=false;output.textContent=error.message;});}});
    el('jobs').append(details);
  }
}
async function run(task){if(busy)return;busy=true;try{await task();}catch(error){message(error.message,true);}finally{busy=false;}}
el('connect').onclick=()=>run(async()=>{pair=parsePair(el('pair').value);sessionStorage.setItem('local-gpt-pair-v1',pair);await refresh();});
el('copy').onclick=()=>run(async()=>{if(!pair)throw Error('연결 코드를 먼저 넣으세요.');await navigator.clipboard.writeText(location.origin+'/#pair='+pair);message('이 폰의 연결 주소를 복사했습니다. 확장 프로그램의 연결 설정에 붙여넣으세요.');});
el('login').onclick=()=>run(async()=>{message('ChatGPT 구독 연결 화면을 여는 중입니다.');const result=await api('/api/login',{});location.assign(result.url);});
el('models').onclick=()=>run(async()=>{const models=await api('/api/models');el('modelList').textContent=models.map(model=>model.name+'\n'+model.slug).join('\n\n')||'사용 가능한 모델이 없습니다.';await refresh();});
el('logout').onclick=()=>run(async()=>{await api('/api/logout',{});el('modelList').textContent='연결을 해제했습니다.';await refresh();});
el('save').onclick=()=>run(async()=>{await api('/api/settings',Object.fromEntries(['max_chars','max_calls_5h','max_calls_24h'].map(key=>[key,Number(el(key).value)])));await refresh();});
el('pause').onclick=()=>run(async()=>{if(!state)await refresh();await api('/api/settings',{paused:!state.settings.paused});await refresh();});
el('refresh').onclick=()=>run(refresh);
if(pair){sessionStorage.setItem('local-gpt-pair-v1',pair);run(refresh);}else message('Termux가 표시한 주소 전체를 열거나 연결 코드를 넣으세요.');
