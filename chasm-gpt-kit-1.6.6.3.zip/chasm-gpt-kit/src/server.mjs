import http from 'node:http';
import fs from 'node:fs/promises';
import os from 'node:os';
import path from 'node:path';
import {fileURLToPath} from 'node:url';
import {random,BridgeError,check,equal} from './auth.mjs';
import {JobBridge} from './jobs.mjs';
export const DEFAULT_PORT=17447;
const ROOT=fileURLToPath(new URL('./',import.meta.url));
function send(res,status,value){res.writeHead(status,{'Content-Type':'application/json; charset=utf-8','Cache-Control':'no-store'});res.end(JSON.stringify(value));}
async function readBody(req){let bytes=0;const chunks=[];for await(const chunk of req){bytes+=chunk.length;check(bytes<=5000000,'BODY_SIZE','요청이 너무 큽니다.',413);chunks.push(chunk);}try{return JSON.parse(Buffer.concat(chunks).toString('utf8')||'{}');}catch{throw new BridgeError('JSON','요청 JSON을 확인하세요.');}}
export async function createServer({dir=path.join(os.homedir(),'.chasm-gpt-subscription-bridge'),fetchImpl=globalThis.fetch,clock=Date.now,appName='Chasm Ignitor GPT Bridge'}={}){
  await fs.mkdir(dir,{recursive:true,mode:0o700});
  const lockFile=path.join(dir,'server.lock'),owner=random();
  let lock;
  try{lock=await fs.open(lockFile,'wx',0o600);}catch(error){
    if(error.code!=='EEXIST')throw error;
    // Serialize stale-lock recovery. Never unlink a newly created live owner's lock.
    const recoveryDir=path.join(dir,'server-lock-recovery');
    try{await fs.mkdir(recoveryDir,{mode:0o700});}catch(e){if(e.code==='EEXIST')throw new BridgeError('STATE_BUSY','서버 잠금을 복구 중입니다. 잠시 후 한 번만 실행하세요.',409);throw e;}
    try{
      let old;try{old=JSON.parse(await fs.readFile(lockFile,'utf8'));}catch{throw new BridgeError('STATE_LOCK','기존 서버 잠금을 확인할 수 없습니다. 파일을 임의 삭제하지 마세요.',409);}
      check(Number.isSafeInteger(old.pid)&&old.pid>0,'STATE_LOCK','서버 잠금 형식이 올바르지 않습니다.',409);
      let alive=true;try{process.kill(old.pid,0);}catch(e){if(e.code==='ESRCH')alive=false;else throw e;}
      check(!alive,'STATE_BUSY','같은 인증·작업 폴더를 사용하는 서버가 이미 실행 중입니다.',409);
      await fs.unlink(lockFile);
      lock=await fs.open(lockFile,'wx',0o600);
      await lock.writeFile(JSON.stringify({pid:process.pid,owner}));await lock.sync();await lock.close();lock=null;
    }finally{await fs.rmdir(recoveryDir);}
    // File already contains this owner's committed metadata.
    lock=await fs.open(lockFile,'r+');
  }
  check(lock,'STATE_LOCK','서버 잠금을 만들지 못했습니다.',409);
  await lock.writeFile(JSON.stringify({pid:process.pid,owner}));await lock.sync();await lock.close();
  const release=async()=>{try{const current=JSON.parse(await fs.readFile(lockFile,'utf8'));if(current.owner===owner)await fs.unlink(lockFile);}catch(error){if(error.code!=='ENOENT')console.error('서버 잠금 해제 실패');}};
  let bridge;try{bridge=await new JobBridge(dir,{fetchImpl,clock,appName}).init();}catch(error){await release();throw error;}

  const server=http.createServer(async(req,res)=>{
    const port=server.address()?.port,base='http://127.0.0.1:'+port;
    res.setHeader('Cache-Control','no-store');res.setHeader('Referrer-Policy','no-referrer');res.setHeader('X-Content-Type-Options','nosniff');res.setHeader('X-Frame-Options','DENY');
    if(req.headers.host!=='127.0.0.1:'+port)return send(res,403,{code:'HOST',message:'127.0.0.1 주소로 연결하세요.'});
    const origin=req.headers.origin;
    // Cross-origin API calls still require the installation's random pair code.
    if(origin&&/^https?:\/\//.test(origin)){res.setHeader('Access-Control-Allow-Origin',origin);res.setHeader('Vary','Origin');}
    if(req.method==='OPTIONS'){res.writeHead(204,{'Access-Control-Allow-Methods':'GET, POST, OPTIONS','Access-Control-Allow-Headers':'Authorization, Content-Type'});res.end();return;}
    try{
      const url=new URL(req.url,base);
      if(url.pathname==='/auth/callback'&&req.method==='GET'){
        await bridge.auth.finishLogin(url);res.writeHead(303,{Location:'/#pair='+bridge.auth.identity.pair});res.end();return;
      }
      const assets={'/':['dashboard.html','text/html'],'/app.js':['dashboard.js','application/javascript'],'/chasm-ignitor-gpt.user.js':['../chasm-ignitor-gpt-1.6.6.3.user.js','text/javascript']};
      if(req.method==='GET'&&Object.hasOwn(assets,url.pathname)){
        const [file,type]=assets[url.pathname];res.setHeader('Content-Security-Policy',"default-src 'self'; script-src 'self'; style-src 'self' 'unsafe-inline'; connect-src 'self'; frame-ancestors 'none'; base-uri 'none'; form-action 'self'");
        res.writeHead(200,{'Content-Type':type+'; charset=utf-8'});res.end(await fs.readFile(path.join(ROOT,file)));return;
      }
      check(equal(req.headers.authorization||'','Bearer '+bridge.auth.identity.pair),'PAIR','관리 화면에서 복사한 로컬 연결 코드가 필요합니다.',401);
      if(req.method==='GET'&&url.pathname==='/api/status')return send(res,200,bridge.status());
      if(req.method==='GET'&&url.pathname==='/api/models')return send(res,200,await bridge.auth.models());
      if(req.method==='POST'&&url.pathname==='/api/login'){check(!bridge.running,'BUSY','진행 중인 작업이 끝난 뒤 로그인하세요.',409);return send(res,200,{url:bridge.auth.startLogin(port)});}
      if(req.method==='POST'&&url.pathname==='/api/logout'){check(!bridge.running,'BUSY','진행 중인 작업이 끝난 뒤 연결을 해제하세요.',409);await bridge.auth.logout();await bridge.settingsChange({paused:true});return send(res,200,{ok:true});}
      if(req.method==='POST'&&url.pathname==='/api/settings')return send(res,200,await bridge.settingsChange(await readBody(req)));
      if(req.method==='POST'&&url.pathname==='/api/jobs')return send(res,202,await bridge.add(await readBody(req)));
      const match=url.pathname.match(/^\/api\/jobs\/([A-Za-z0-9_-]{16,100})(?:\/(resume))?$/);
      if(match&&req.method==='GET'&&!match[2])return send(res,200,bridge.get(match[1]));
      if(match&&req.method==='POST'&&match[2]==='resume')return send(res,200,await bridge.resume(match[1]));
      send(res,404,{code:'PATH',message:'없는 경로입니다.'});
    }catch(error){send(res,error instanceof BridgeError?error.status:500,{code:error instanceof BridgeError?error.code:'LOCAL_ERROR',message:error instanceof BridgeError?error.message:'로컬 처리 중 오류가 발생했습니다. 같은 요청을 자동으로 다시 보내지 마세요.'});}
  });
  server.on('close',()=>{bridge.close();void release();});
  server.on('error',()=>{bridge.close();void release();});
  return {server,bridge};
}
if(process.argv[1]&&path.resolve(process.argv[1])===fileURLToPath(import.meta.url)){
  const port=Number(process.env.GPT_BRIDGE_PORT||DEFAULT_PORT);
  check(Number.isInteger(port)&&port>=1024&&port<=65535,'PORT','사용할 포트를 확인하세요.');
  const {server,bridge}=await createServer();
  server.listen(port,'127.0.0.1',()=>console.log('\nChasm Ignitor GPT Bridge 0.1.1\n관리 화면: http://127.0.0.1:'+port+'/#pair='+bridge.auth.identity.pair+'\n각자 본인 계정으로 로그인하세요. 종료: Ctrl+C\n'));
  server.on('error',error=>{bridge.close();console.error(error.code==='EADDRINUSE'?'해당 포트가 이미 사용 중입니다. 기존 서버를 확인하거나 GPT_BRIDGE_PORT를 바꾸세요.':'서버를 시작하지 못했습니다.');process.exitCode=1;});
  for(const signal of ['SIGINT','SIGTERM'])process.on(signal,()=>{bridge.close();server.close(()=>process.exit(0));});
}
