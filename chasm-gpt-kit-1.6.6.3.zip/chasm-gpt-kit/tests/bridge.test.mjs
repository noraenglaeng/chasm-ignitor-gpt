import test, {after} from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs/promises';
import os from 'node:os';
import path from 'node:path';
import crypto from 'node:crypto';
import vm from 'node:vm';
import http from 'node:http';
import {SubscriptionAuth,API,AUTH} from '../src/auth.mjs';
import {JobBridge,readCompleted} from '../src/jobs.mjs';
import {createServer} from '../src/server.mjs';
const testTemp=new URL('../.test-tmp-bridge/',import.meta.url);
await fs.mkdir(testTemp,{recursive:true});
after(()=>fs.rm(testTemp,{recursive:true,force:true}));


const {privateKey,publicKey}=crypto.generateKeyPairSync('rsa',{modulusLength:2048});
const jwk={...publicKey.export({format:'jwk'}),kid:'unit-key',alg:'RS256',use:'sig'};
const json=(value,status=200)=>new Response(JSON.stringify(value),{status,headers:{'Content-Type':'application/json'}});
const event=(type,value={})=>'data: '+JSON.stringify({type,...value})+'\n\n';
const complete=text=>event('response.output_text.delta',{delta:text})+event('response.completed',{response:{status:'completed',output:[{type:'message',content:[{type:'output_text',text}]}],usage:{input_tokens:12,output_tokens:8}}});
const jwt=claims=>{const head=Buffer.from(JSON.stringify({alg:'RS256',kid:'unit-key'})).toString('base64url'),body=Buffer.from(JSON.stringify(claims)).toString('base64url');return head+'.'+body+'.'+crypto.sign('sha256',Buffer.from(head+'.'+body),privateKey).toString('base64url');};
async function directory(t){const dir=await fs.mkdtemp(path.join(decodeURIComponent(testTemp.pathname),'local-gpt-kit-test-'));t.after(()=>fs.rm(dir,{recursive:true,force:true}));return dir;}
function upstream(handler){
  const state={calls:0,requests:[],refreshes:0,claims:null,scope:'openid profile email offline_access resource.invoke chatgpt.tokens.use.direct'};
  state.fetch=async(url,options={})=>{
    url=String(url);
    if(url===AUTH+'/.well-known/openid-configuration')return json({issuer:AUTH,jwks_uri:AUTH+'/unit-jwks',revocation_endpoint:AUTH+'/unit-revoke'});
    if(url===AUTH+'/unit-jwks')return json({keys:[jwk]});
    if(url===AUTH+'/unit-revoke')return json({});
    if(url===AUTH+'/api/accounts/oauth/token'){
      const form=new URLSearchParams(options.body);if(form.get('grant_type')==='refresh_token'){state.refreshes++;return json({access_token:'unit-refreshed',refresh_token:'unit-rotated',scope:state.scope,expires_in:3600});}
      state.exchange=form;return json({access_token:'unit-access',refresh_token:'unit-refresh',id_token:jwt(state.claims),scope:state.scope,expires_in:3600});
    }
    if(url===API+'/models')return json({models:[{slug:'unit-model',display_name:'Unit Model',visibility:'list'},{slug:'hidden',visibility:'hidden'}]});
    if(url===API+'/responses'){state.calls++;const body=JSON.parse(options.body);state.requests.push(body);return handler?handler(body,state.calls):new Response(complete('테스트 번역'));}
    throw Error('Unexpected upstream URL');
  };return state;
}
function seed(bridge){bridge.auth.tokens={client_id:'oaiapp_unit',subject:'unit-user',access_token:'unit-access',refresh_token:'unit-refresh',scopes:['chatgpt.tokens.use.direct'],expires_at:Date.now()+3600000};}
const payload=(id=crypto.randomUUID(),input='Translate this sample.')=>({request_id:id,model:'unit-model',effort:'medium',instructions:'Translate only.',input});
async function fixture(t,handler){const dir=await directory(t),remote=upstream(handler),bridge=await new JobBridge(dir,{fetchImpl:remote.fetch}).init();seed(bridge);t.after(()=>bridge.close());return {dir,remote,bridge};}
async function settled(bridge,id){for(let i=0;i<200;i++){const job=bridge.get(id);if(!['running','queued'].includes(job.status))return job;await new Promise(resolve=>setTimeout(resolve,5));}throw Error('Mock job did not settle');}

test('host and pair are unique per installation and persist across restarts',async t=>{
  const dir=await directory(t),a=await new SubscriptionAuth(dir).init(),again=await new SubscriptionAuth(dir).init(),b=await new SubscriptionAuth(await directory(t)).init();
  assert.deepEqual(a.identity,again.identity);assert.notEqual(a.identity.host_id,b.identity.host_id);assert.notEqual(a.identity.pair,b.identity.pair);
});
test('official dynamic OAuth, issued client ID, PKCE, signature and plan scope round trip',async t=>{
  const remote=upstream(),dir=await directory(t),auth=await new SubscriptionAuth(dir,{fetchImpl:remote.fetch}).init();
  const url=new URL(auth.startLogin(17446));assert.equal(url.origin,AUTH);assert.equal(url.searchParams.get('client_id'),'dynamic_agent_client');assert.equal(url.searchParams.get('resource'),API);assert.equal(url.searchParams.get('code_challenge_method'),'S256');
  remote.claims={iss:AUTH,aud:'oaiapp_unit',sub:'unit-user',nonce:url.searchParams.get('nonce'),exp:Date.now()/1000+300};
  const callback=new URL('http://127.0.0.1:17446/auth/callback');callback.searchParams.set('state',url.searchParams.get('state'));callback.searchParams.set('client_id','oaiapp_unit');callback.searchParams.set('code','unit-code');
  await auth.finishLogin(callback);assert.equal(auth.tokens.client_id,'oaiapp_unit');assert.equal(remote.exchange.get('client_id'),'oaiapp_unit');assert.equal(remote.exchange.get('redirect_uri'),'http://127.0.0.1:17446/auth/callback');
  assert.equal((await fs.stat(auth.file('account.json'))).mode&0o777,0o600);
  const returning=new URL(auth.startLogin(17447));assert.equal(returning.searchParams.get('client_id'),'oaiapp_unit');assert.equal(returning.searchParams.get('agent_name_hint'),null);
  assert.deepEqual(await auth.models(),[{slug:'unit-model',name:'Unit Model'}]);assert.equal(remote.calls,0);
});
test('login rejects state, signature, audience and nonce mismatches',async t=>{
  const remote=upstream(),auth=await new SubscriptionAuth(await directory(t),{fetchImpl:remote.fetch}).init();auth.startLogin(17446);
  await assert.rejects(auth.finishLogin(new URL('http://127.0.0.1/auth/callback?state=wrong')),{code:'LOGIN_STATE'});
  const claims={iss:AUTH,aud:'oaiapp_unit',sub:'unit-user',nonce:'known',exp:Date.now()/1000+300};
  await assert.rejects(auth.verifyID(jwt(claims),{clientId:'other'}),{code:'ID_CLAIMS'});
  await assert.rejects(auth.verifyID(jwt(claims),{clientId:'oaiapp_unit',nonce:'wrong'}),{code:'ID_NONCE'});
  const parts=jwt(claims).split('.');parts[1]=Buffer.from(JSON.stringify({...claims,sub:'modified'})).toString('base64url');await assert.rejects(auth.verifyID(parts.join('.'),{clientId:'oaiapp_unit'}),{code:'ID_SIGNATURE'});
});
test('login without explicit plan permission does not commit credentials',async t=>{
  const remote=upstream(),auth=await new SubscriptionAuth(await directory(t),{fetchImpl:remote.fetch}).init(),url=new URL(auth.startLogin(17446));remote.scope='openid profile';
  remote.claims={iss:AUTH,aud:'oaiapp_unit',sub:'unit-user',nonce:url.searchParams.get('nonce'),exp:Date.now()/1000+300};
  const callback=new URL('http://127.0.0.1/auth/callback');for(const [k,v]of Object.entries({state:url.searchParams.get('state'),client_id:'oaiapp_unit',code:'unit'}))callback.searchParams.set(k,v);
  await assert.rejects(auth.finishLogin(callback),{code:'PLAN_PERMISSION'});assert.equal(auth.tokens,null);await assert.rejects(fs.stat(auth.file('account.json')),{code:'ENOENT'});
});
test('concurrent refreshes rotate credentials once and retain the refreshed token',async t=>{
  const {bridge,remote}=await fixture(t);bridge.auth.tokens.expires_at=0;
  assert.deepEqual(await Promise.all([bridge.auth.access(),bridge.auth.access()]),['unit-refreshed','unit-refreshed']);assert.equal(remote.refreshes,1);assert.equal(bridge.auth.tokens.refresh_token,'unit-rotated');
});
test('concurrent identical submissions run exactly one independent Responses request',async t=>{
  const {bridge,remote}=await fixture(t),data=payload();await Promise.all([bridge.add(data),bridge.add(data),bridge.add(data)]);
  const job=await settled(bridge,data.request_id);assert.equal(job.status,'completed');assert.equal(job.text,'테스트 번역');assert.equal(remote.calls,1);
  assert.equal(remote.requests[0].store,false);assert.equal(remote.requests[0].stream,true);assert.deepEqual(remote.requests[0].input,[{role:'user',content:data.input}]);
  assert.equal(JSON.stringify(job).includes('unit-access'),false);assert.equal(Object.hasOwn(job,'body'),false);assert.equal(Object.hasOwn(job,'fingerprint'),false);
});
test('changing source, prompt or model under the same request ID is rejected',async t=>{
  const {bridge,remote}=await fixture(t),data=payload();await bridge.add(data);await settled(bridge,data.request_id);
  for(const change of [{input:'Different source'},{instructions:'Different prompt'},{model:'other'}])await assert.rejects(bridge.add({...data,...change}),{code:'REQUEST_CHANGED'});
  assert.equal(remote.calls,1);
});
test('source histories keep role and order and explicit unsupported fields are rejected',async t=>{
  const {bridge,remote}=await fixture(t),data=payload();data.input=[{role:'user',content:'First'},{role:'assistant',content:'Second'},{role:'user',content:'Translate'}];
  await bridge.add(data);await settled(bridge,data.request_id);assert.deepEqual(remote.requests[0].input,data.input);
  await assert.rejects(bridge.add({...payload(),temperature:1}),{code:'PAYLOAD_FIELDS'});
  await assert.rejects(bridge.add({...payload(),input:[{role:'system',content:'Unsupported'}]}),{code:'TEXT_ONLY'});assert.equal(remote.calls,1);
});
test('truncated streams preserve partial text and never become completed',async t=>{
  const {bridge,remote}=await fixture(t,()=>new Response(event('response.output_text.delta',{delta:'부분 결과'}))),data=payload();
  await bridge.add(data);const job=await settled(bridge,data.request_id);assert.equal(job.status,'error');assert.equal(job.error_code,'NOT_COMPLETED');assert.equal(job.partial_text,'부분 결과');
  await bridge.add(data);assert.equal(remote.calls,1);
});
test('late subscription quota errors pause new work without automatic retry',async t=>{
  const {bridge,remote}=await fixture(t,()=>new Response(event('response.output_text.delta',{delta:'부분'})+event('response.failed',{response:{error:{code:'subscription_sharing_usage_limit_exceeded'}}}))),data=payload();
  await bridge.add(data);const job=await settled(bridge,data.request_id);assert.equal(job.status,'error');assert.equal(job.partial_text,'부분');assert.equal(bridge.settings.paused,true);await bridge.add(data);assert.equal(remote.calls,1);
});
test('HTTP 429 pauses the bridge and does not create API-key fallback calls',async t=>{
  const {bridge,remote}=await fixture(t,()=>json({error:{code:'HTTP_429'}},429)),data=payload();await bridge.add(data);const job=await settled(bridge,data.request_id);
  assert.equal(job.status,'error');assert.equal(bridge.settings.paused,true);assert.equal(remote.calls,1);
});
test('local call budget blocks before inference and explicit resume keeps the same ID',async t=>{
  const {bridge,remote}=await fixture(t);await bridge.settingsChange({max_calls_5h:1});const one=payload(),two=payload();await bridge.add(one);await settled(bridge,one.request_id);await bridge.add(two);
  let job=await settled(bridge,two.request_id);assert.equal(job.status,'blocked_budget');assert.equal(job.attempts,0);assert.equal(remote.calls,1);
  await bridge.settingsChange({max_calls_5h:2});await bridge.resume(two.request_id);job=await settled(bridge,two.request_id);assert.equal(job.status,'completed');assert.equal(remote.calls,2);
});
test('completed results survive restart and GET does not regenerate them',async t=>{
  const {bridge,dir,remote}=await fixture(t),data=payload();await bridge.add(data);await settled(bridge,data.request_id);bridge.close();
  const next=await new JobBridge(dir,{fetchImpl:remote.fetch}).init();t.after(()=>next.close());assert.equal(next.get(data.request_id).text,'테스트 번역');await next.add(data);assert.equal(remote.calls,1);
});
test('jobs queued when a process stops require review instead of automatic restart',async t=>{
  const {bridge,dir,remote}=await fixture(t);await bridge.settingsChange({paused:true});const data=payload();await bridge.add(data);bridge.close();
  const next=await new JobBridge(dir,{fetchImpl:remote.fetch}).init();t.after(()=>next.close());assert.equal(next.get(data.request_id).error_code,'INTERRUPTED');await next.settingsChange({paused:false});assert.equal(remote.calls,0);
});
test('refusals, incomplete terminals and empty completed responses are not applied',async()=>{
  for(const raw of [event('response.refusal.delta',{delta:'refused'}),event('response.incomplete',{response:{status:'incomplete'}}),complete('')])await assert.rejects(readCompleted(new Response(raw).body));
});
test('HTTP pair and Host checks protect the generic server; auth flow and GET endpoints are usable',async t=>{
  const remote=upstream(),{server,bridge}=await createServer({dir:await directory(t),fetchImpl:remote.fetch});
  await new Promise(resolve=>server.listen(0,'127.0.0.1',resolve));t.after(async()=>{bridge.close();server.closeAllConnections();await new Promise(resolve=>server.close(resolve));});
  const base='http://127.0.0.1:'+server.address().port,headers={Authorization:'Bearer '+bridge.auth.identity.pair,'Content-Type':'application/json'};
  assert.equal((await fetch(base+'/api/status')).status,401);
  const wrongHost=await new Promise((resolve,reject)=>{const request=http.request(base+'/api/status',{headers:{...headers,Host:'attacker.invalid'}},response=>{response.resume();resolve(response.statusCode);});request.on('error',reject);request.end();});
  assert.equal(wrongHost,403);
  const status=await (await fetch(base+'/api/status',{headers})).json();assert.equal(status.connected,false);assert.equal(JSON.stringify(status).includes(bridge.auth.identity.pair),false);
  const login=await (await fetch(base+'/api/login',{method:'POST',headers,body:'{}'})).json(),authURL=new URL(login.url);
  remote.claims={iss:AUTH,aud:'oaiapp_unit',sub:'unit-user',nonce:authURL.searchParams.get('nonce'),exp:Date.now()/1000+300};
  const cb=new URL(base+'/auth/callback');for(const [key,value]of Object.entries({state:authURL.searchParams.get('state'),client_id:'oaiapp_unit',code:'unit'}))cb.searchParams.set(key,value);
  const callback=await fetch(cb,{redirect:'manual'});assert.equal(callback.status,303);assert.equal((await fetch(base+'/api/models',{headers})).status,200);
  const data=payload();assert.equal((await fetch(base+'/api/jobs',{method:'POST',headers,body:JSON.stringify(data)})).status,202);await settled(bridge,data.request_id);
  assert.equal((await (await fetch(base+'/api/jobs/'+data.request_id,{headers})).json()).status,'completed');assert.equal(remote.calls,1);
});

const clientSource=await fs.readFile(new URL('../examples/tampermonkey-client.js',import.meta.url),'utf8');
function clientFixture(){
  const storage=new Map(),calls=[],connection='http://127.0.0.1:17446/#pair='+('x'.repeat(43));
  const Client=vm.runInNewContext(clientSource+'\nLocalGPTClient',{crypto:crypto.webcrypto,TextEncoder,URL,URLSearchParams,setTimeout});
  const client=new Client({connection,getValue:async(key,fallback)=>storage.get(key)??fallback,setValue:async(key,value)=>storage.set(key,value),request:options=>{calls.push(options);if(options.method==='POST')options.ontimeout();else options.onload({status:200,responseText:JSON.stringify({status:'completed',text:'보관된 결과'})});}});
  return {client,storage,calls};
}
test('userscript stores ID before uncertain POST and reloaded submit only reads the same job',async()=>{
  const {client,calls}=clientFixture(),data={model:'unit-model',instructions:'Translate',input:'sample'};
  await assert.rejects(client.submit({message:'unit'},data));const id=(await client.pending()).request_id;assert.ok(id);
  const result=await client.submit({message:'unit'},data);assert.equal(result.text,'보관된 결과');assert.deepEqual(calls.map(c=>c.method),['POST','GET']);assert.ok(calls[1].url.endsWith(id));
});
test('userscript refuses changed source until the older result is deliberately handled',async()=>{
  const {client,calls}=clientFixture(),context={message:'unit'},data={model:'unit-model',input:'sample'};
  await assert.rejects(client.submit(context,data));await assert.rejects(client.submit(context,{...data,input:'changed'}));assert.equal(calls.length,1);
  const id=(await client.pending()).request_id;await client.acknowledge('wrong-id');assert.equal((await client.pending()).request_id,id);await client.acknowledge(id);assert.equal(await client.pending(),null);
});
