import test, {after} from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs/promises';
import vm from 'node:vm';
import crypto from 'node:crypto';
import os from 'node:os';
import path from 'node:path';
import {createServer,DEFAULT_PORT} from '../src/server.mjs';
import {JobBridge,readCompleted} from '../src/jobs.mjs';
const testTemp=new URL('../.test-tmp-chasm/',import.meta.url);
await fs.mkdir(testTemp,{recursive:true});
after(()=>fs.rm(testTemp,{recursive:true,force:true}));
const script=await fs.readFile(new URL('../chasm-ignitor-gpt-1.6.6.3.user.js',import.meta.url),'utf8');
const original=await fs.readFile(new URL('../original/chasm-ignitor-1.6.6.2.txt',import.meta.url),'utf8');
const clientCode=script.slice(script.indexOf('class ChasmGPTClient'),script.indexOf('// @ts-check'));
// Uses the class embedded in the delivered .user.js, not the reference example.
function locks(){const busy=new Set();return {async request(name,options,action){if(busy.has(name))return action(null);busy.add(name);try{return await action({name});}finally{busy.delete(name);}}};}
function fixture({storage=new Map(),lock=locks(),handler}={}){
  const calls=[];
  const Client=vm.runInNewContext(clientCode+'\nChasmGPTClient',{crypto:crypto.webcrypto,TextEncoder,URL,URLSearchParams,setTimeout,navigator:{locks:lock}});
  const client=new Client({connection:'http://127.0.0.1:17447/#pair='+'z'.repeat(43),getValue:(k,d)=>structuredClone(storage.get(k)??d),setValue:async(k,v)=>storage.set(k,structuredClone(v)),locks:lock,request:options=>{calls.push(options);if(handler)handler(options,storage);else if(options.method==='POST')options.ontimeout();else options.onload({status:200,responseText:JSON.stringify({request_id:options.url.split('/').at(-1),status:'completed',text:'saved',usage:{input_tokens:7,output_tokens:4}})});}});
  return {client,Client,calls,storage,lock};
}
const context={roomId:'room-a',maxCount:100,sourceHash:'hash',targetId:'msg-1',targetHash:'hash2'};
const payload={model:'unit-model',input:'source'};

test('delivered script keeps identity, old settings/DB, dependencies and exact embedded prompts',()=>{
  for(const tag of ['@name','@namespace'])assert.equal(original.split('\n').find(l=>l.includes(tag)).trim(),script.split('\n').find(l=>l.includes(tag)).trim());
  assert.ok(script.includes('// @updateURL    none'));assert.ok(script.includes('// @downloadURL  none'));
  assert.ok(script.includes('@connect      127.0.0.1'));assert.ok(script.includes('@grant        GM_getValue'));assert.ok(script.includes('@noframes'));
  const block=s=>s.slice(s.indexOf('  const DEFAULT_PROMPTS = {'),s.indexOf('  // =================================================\n  //                  메뉴 강제 추가'));
  assert.equal(block(script),block(original));
  assert.ok(script.includes('new Dexie("chasm-ignitor")'));assert.ok(script.includes('const PLATFORM_SAVE_KEY = "chasm-ignt-settings"'));
  for(const line of original.split('\n').filter(l=>l.includes('// @require')))assert.ok(script.includes(line));
});
test('real client commits ID before POST; refresh and GET 404 never re-POST',async()=>{
  const shared=new Map();let committed;
  const a=fixture({storage:shared,handler:(o,s)=>{committed=s.get('chasm-gpt-request-ledger-v1')?.latest;o.ontimeout();}});
  await assert.rejects(a.client.submit(context,payload));assert.ok(committed);
  const b=fixture({storage:shared,handler:o=>o.onload({status:404,responseText:'{"code":"NOT_FOUND"}'})});
  await assert.rejects(b.client.submit(context,payload));await assert.rejects(b.client.submit(context,payload));
  assert.deepEqual(b.calls.map(o=>o.method),['GET','GET']);assert.ok(b.calls.every(o=>o.url.endsWith(committed)));
});
test('storage write failure stops before POST',async()=>{
  const f=fixture();f.client.setValue=async()=>{throw Error('disk full');};
  await assert.rejects(f.client.submit(context,payload));assert.equal(f.calls.length,0);
});
test('cross-tab click lock admits one POST; no-Web-Locks fails closed',async()=>{
  const shared=new Map(),lock=locks(),a=fixture({storage:shared,lock}),b=fixture({storage:shared,lock});
  await Promise.allSettled([a.client.submit(context,payload),b.client.submit(context,payload)]);
  assert.equal([...a.calls,...b.calls].filter(c=>c.method==='POST').length,1);
  const c=fixture();c.client.locks=null;await assert.rejects(c.client.submit(context,payload));assert.equal(c.calls.length,0);
});
test('uncertain old request blocks different source/model until an explicit retire',async()=>{
  const f=fixture();await assert.rejects(f.client.submit(context,payload));
  await assert.rejects(f.client.submit({...context,roomId:'room-b'},payload));
  await assert.rejects(f.client.submit(context,{...payload,model:'other'}));assert.equal(f.calls.length,1);
  const id=(await f.client.latest()).request_id;await f.client.retireLatest();
  await assert.rejects(f.client.submit(context,payload));assert.equal(f.calls.length,2);assert.notEqual((await f.client.latest()).request_id,id);
  assert.ok((await f.client.ledger()).records[id].retired);
});
test('completed result stays durable and same input reuses original ID after refresh',async()=>{
  const f=fixture();await assert.rejects(f.client.submit(context,payload));const id=(await f.client.latest()).request_id;
  const job=await f.client.wait(id,{maxWaitMs:0});await f.client.saveCompleted(job);
  const g=fixture({storage:f.storage});await g.client.submit(context,payload);
  assert.deepEqual(g.calls.map(o=>o.method),['GET']);assert.equal((await g.client.latest()).result.text,'saved');
  await g.client.markApply(id,'applying');await assert.rejects(g.client.markApply(id,'applying'));await g.client.markApply(id,'applied');
});
test('partial/error/refusal client results cannot be marked saved or applied',async()=>{
  const f=fixture();await assert.rejects(f.client.submit(context,payload));const id=(await f.client.latest()).request_id;
  for(const status of ['running','error','blocked_budget'])await assert.rejects(f.client.saveCompleted({request_id:id,status,text:'partial'}));
  await assert.rejects(f.client.markApply(id,'applying'));
});
test('wrong request ID and unexpected job state never complete',async()=>{
  for(const value of [{request_id:'wrong',status:'completed',text:'bad'}, {request_id:'correct-request-id',status:'refused',text:'bad'}]){
    const f=fixture({handler:o=>o.onload({status:200,responseText:JSON.stringify(value)})});
    await assert.rejects(f.client.wait('correct-request-id',{maxWaitMs:0}));
  }
});
test('OAuth-like or remote connection values are not accepted as local pair URLs',()=>{
  const {Client}=fixture();
  for(const connection of ['https://example.org/#pair='+'x'.repeat(43),'http://localhost:17447/#pair='+'x'.repeat(43),'http://127.0.0.1:17447/path#pair='+'x'.repeat(43),'http://user:pass@127.0.0.1:17447/#pair='+'x'.repeat(43),'http://127.0.0.1:17447/'])assert.throws(()=>new Client({connection}));
});
const adapters=script.slice(script.indexOf('  const GPT_PROVIDER'),script.indexOf('  class PlatformMessage {'));
const typeCode=script.slice(script.indexOf('  class TokenUsage'),script.indexOf('  class GeminiRequester'));
function adapterFixture(extra={}){
  const f=fixture(),saves=[];
  const sandbox={crypto:crypto.webcrypto,TextEncoder,URL,URLSearchParams,setTimeout,ChasmGPTClient:f.Client,GM_getValue:(k,d)=>f.storage.get(k)??d,GM_setValue:async(k,v)=>f.storage.set(k,v),GM_xmlhttpRequest:null,console,
    navigator:{locks:f.lock},settings:{config:{}},...extra};
  vm.createContext(sandbox);
  vm.runInContext(clientCode+'\n'+typeCode+'\n'+adapters+'\nthis.testAPI={ChatGPTRequester,captureGPTContext,verifyGPTContext,applyGPTResult,gptTarget,ReconstructableResponse,TokenUsage,GenericLLMResponse,LLMError};',sandbox);
  return {...f,sandbox,api:sandbox.testAPI,saves};
}
test('adapter converts a completed job to original GenericLLMResponse and TokenUsage',async()=>{
  const a=adapterFixture();const c={connection:a.client.connection,models:[{slug:'unit-model'}],effort:''};a.storage.set(a.Client.CONFIG_KEY,c);
  a.sandbox.GM_xmlhttpRequest=o=>o.onload({status:200,responseText:JSON.stringify({request_id:JSON.parse(o.data||'{}').request_id,status:'completed',text:'요약 결과',usage:{input_tokens:11,output_tokens:9}})});
  const answer=await a.api.ChatGPTRequester.GENERIC_REQUESTER.doRequest({modelId:'unit-model',prompt:'{"prompt":"task","chatLog":[]}',gptContext:context,useRandomPrefix:true});
  assert.ok(answer instanceof a.api.GenericLLMResponse,answer.message);assert.equal(answer.message,'요약 결과');assert.equal(answer.tokenUsage.total(),20);
  assert.equal(answer.bridgeContext.roomId,'room-a');assert.ok(answer.bridgeRequestId);assert.ok((await a.client.latest()).saved);
});
test('adapter maps HTTP errors to non-recoverable original LLMError (no retry loop)',async()=>{
  const a=adapterFixture();a.storage.set(a.Client.CONFIG_KEY,{connection:a.client.connection,models:[{slug:'unit-model'}],effort:''});let calls=0;
  a.sandbox.GM_xmlhttpRequest=o=>{calls++;o.onload({status:429,responseText:'{"code":"HTTP_429","message":"limit"}'});};
  const answer=await a.api.ChatGPTRequester.GENERIC_REQUESTER.doRequest({modelId:'unit-model',prompt:'input',gptContext:context});
  assert.ok(answer instanceof a.api.LLMError);assert.equal(answer.isRecoverable,false);assert.equal(calls,1);
});
test('source guard rejects room movement, source edits/rerolls and in-progress latest response',async()=>{
  let room='room-a',snapshot=[{id:'m1',role:'assistant',content:'original',status:'completed'}];
  const a=adapterFixture({PlatformProvider:{getProvider:()=>({getCurrentId:()=>room})},CrackMessageFetcher:class{constructor(chatId){this.chatId=chatId;}async fetch(){this.gptSourceSnapshot=snapshot;return [];}}});
  const base=await a.api.captureGPTContext({chatId:room,gptSourceSnapshot:snapshot},50);
  await a.api.verifyGPTContext(base);
  room='room-b';await assert.rejects(a.api.verifyGPTContext(base));room='room-a';
  snapshot=[{id:'m1',role:'assistant',content:'rerolled',status:'completed'}];await assert.rejects(a.api.verifyGPTContext(base));
  snapshot=[{id:'m1',role:'assistant',content:'partial',status:'streaming'}];await assert.rejects(a.api.captureGPTContext({chatId:room,gptSourceSnapshot:snapshot},50));
});
test('original completed-turn fetcher implementation retained with only snapshot capture added',()=>{
  const section=s=>s.slice(s.indexOf('  class CrackMessageFetcher'),s.indexOf('  class CrackUserNoteUtility'));
  assert.equal(section(script).replace('            this.gptSourceSnapshot = all.map(gptSnapshotItem);\n',''),section(original));
});
test('same state directory cannot be served concurrently by another server',async t=>{
  const dir=await fs.mkdtemp(path.join(decodeURIComponent(testTemp.pathname),'chasm-lock-test-'));
  const a=await createServer({dir});await new Promise(r=>a.server.listen(0,'127.0.0.1',r));
  t.after(async()=>{a.bridge.close();await new Promise(r=>a.server.close(r));await fs.rm(dir,{recursive:true,force:true});});
  await assert.rejects(createServer({dir}),{code:'STATE_BUSY'});assert.equal(DEFAULT_PORT,17447);
});
test('SSE with a terminal refusal, tool call, missing terminal output or failed tail cannot be applied',async()=>{
  const event=(type,value)=>'data: '+JSON.stringify({type,...value})+'\n\n';
  const complete=output=>event('response.completed',{response:{status:'completed',output}});
  const text=[{type:'message',content:[{type:'output_text',text:'text'}]}];
  for(const raw of [complete([{type:'message',content:[{type:'refusal',refusal:'no'}]}]),complete([{type:'function_call',name:'tool'}]),event('response.output_text.delta',{delta:'partial'})+complete([]),complete(text)+event('response.failed',{response:{error:{code:'late_error'}}})])await assert.rejects(readCompleted(new Response(raw).body));
});

test('apply path uses original sender, preserves wrappers, commits applying before PATCH and blocks a second send',async()=>{
  let writes=0,posted='',a;
  const native=[{id:'m1',role:'assistant',content:'original',status:'completed'}];
  const nodes={'chasm-ignt-result-panel':{value:'사용자 수정 요약'},'chasm-ignt-status-text':{textContent:''}};
  a=adapterFixture({document:{getElementById:id=>nodes[id]},PlatformProvider:{getProvider:()=>({getCurrentId:()=>context.roomId,getSender:()=>({send:async(_,expected)=>{
    assert.equal(expected.targetId,'m1');return async text=>{assert.equal((await a.client.latest()).applyState,'applying');writes++;posted=text;};
  }})})},CrackMessageFetcher:class{constructor(chatId){this.chatId=chatId;}async fetch(){this.gptSourceSnapshot=native;return [];}}});
  const captured=await a.api.captureGPTContext({chatId:context.roomId,gptSourceSnapshot:native},100);
  await assert.rejects(a.client.submit(captured,payload));const id=(await a.client.latest()).request_id;
  await a.client.saveCompleted({request_id:id,status:'completed',text:'original result'});
  a.sandbox.settings.config={promptPrefixMessage:'PREFIX',promptSuffixMessage:'SUFFIX'};
  a.storage.set(a.Client.CONFIG_KEY,{connection:a.client.connection,models:[]});
  const result={bridgeRequestId:id,bridgeContext:captured};
  await a.api.applyGPTResult(result);assert.equal(writes,1);assert.equal(posted,'PREFIX\n사용자 수정 요약\nSUFFIX');
  assert.equal((await a.client.latest()).applyState,'applied');assert.equal((await a.client.latest()).editedText,'사용자 수정 요약');
  await assert.rejects(a.api.applyGPTResult(result));assert.equal(writes,1);
});
test('apply rejects moved source before calling sender and leaves completed result stored',async()=>{
  let calls=0,room=context.roomId;
  const a=adapterFixture({PlatformProvider:{getProvider:()=>({getCurrentId:()=>room,getSender:()=>{calls++;throw Error('must not send');}})}});
  await assert.rejects(a.client.submit(context,payload));const id=(await a.client.latest()).request_id;await a.client.saveCompleted({request_id:id,status:'completed',text:'summary'});
  room='different';await assert.rejects(a.api.applyGPTResult({bridgeRequestId:id,bridgeContext:context}));
  assert.equal(calls,0);assert.equal((await a.client.latest()).result.text,'summary');
});
test('uncertain native PATCH is never retried by the result button',async()=>{
  const native=[{id:'m1',role:'assistant',content:'original',status:'completed'}];let sends=0;
  const a=adapterFixture({document:{getElementById:()=>({value:'summary'})},PlatformProvider:{getProvider:()=>({getCurrentId:()=>context.roomId,getSender:()=>({send:async()=>async()=>{sends++;throw Error('network uncertain');}})})},CrackMessageFetcher:class{constructor(chatId){this.chatId=chatId;}async fetch(){this.gptSourceSnapshot=native;return [];}}});
  const captured=await a.api.captureGPTContext({chatId:context.roomId,gptSourceSnapshot:native},100);
  await assert.rejects(a.client.submit(captured,payload));const id=(await a.client.latest()).request_id;await a.client.saveCompleted({request_id:id,status:'completed',text:'summary'});
  const result={bridgeRequestId:id,bridgeContext:captured};await assert.rejects(a.api.applyGPTResult(result));await assert.rejects(a.api.applyGPTResult(result));
  assert.equal(sends,1);assert.equal((await a.client.latest()).applyState,'applying');
});
test('modified native sender checks exact target ID/content twice and blocks a last-moment reroll',async()=>{
  const senderCode=script.slice(script.indexOf('  class CrackMessageSender'),script.indexOf('  class CrackMessageFetcher'));
  let room='r',latest={_id:'m1',role:'assistant',content:'original'},patches=0;
  const {Client}=fixture();
  const Sender=vm.runInNewContext(senderCode+'\nCrackMessageSender',{PlatformMessageSender:class{},ChasmGPTClient:Client,Error,CrackUtil:{path:()=>({chatRoom:()=>room}),network:()=>({authFetch:async(method)=>{if(method==='PATCH'){patches++;return {};}return {data:{messages:[latest]}};}})},CrackMessageFetcher:class{async readPage(){return {messages:[latest]};}},gptSnapshotItem:m=>({id:m._id,role:m.role,content:m.content,status:''}),gptTarget:s=>s[0]});
  const expected={roomId:'r',targetId:'m1',targetHash:await Client.hash('original')};
  const modifier=await new Sender('r').send('',expected);assert.equal(typeof modifier,'function');
  latest={...latest,_id:'m2',content:'rerolled'};assert.ok(await modifier('summary') instanceof Error);assert.equal(patches,0);
});
test('stale process lock recovers and uses the same data without replaying jobs',async t=>{
  const dir=await fs.mkdtemp(path.join(decodeURIComponent(testTemp.pathname),'chasm-stale-lock-'));
  await fs.writeFile(path.join(dir,'server.lock'),JSON.stringify({pid:2147483647,owner:'previous'}));
  const {server,bridge}=await createServer({dir});await new Promise(r=>server.listen(0,'127.0.0.1',r));
  t.after(async()=>{bridge.close();await new Promise(r=>server.close(r));await fs.rm(dir,{recursive:true,force:true});});
  assert.equal(JSON.parse(await fs.readFile(path.join(dir,'server.lock'),'utf8')).pid,process.pid);
});
test('persona and user-note changes invalidate a saved result before application',async()=>{
  const native=[{id:'m1',role:'assistant',content:'original',status:'completed'}];let note='original note';
  const provider={getCurrentId:()=>context.roomId,getPersonaUtil:()=>({getRepresentivePersona:async()=>({name:'name',description:'description'})}),getUserNoteUtil:()=>({fetch:async()=>note})};
  const a=adapterFixture({PlatformProvider:{getProvider:()=>provider},CrackMessageFetcher:class{constructor(chatId){this.chatId=chatId;}async fetch(){this.gptSourceSnapshot=native;return [];}}});
  const captured=await a.api.captureGPTContext({chatId:context.roomId,gptSourceSnapshot:native},50,{userPersonaName:'name',userPersonaDescription:'description',userNote:note});
  await a.api.verifyGPTContext(captured);note='changed';await assert.rejects(a.api.verifyGPTContext(captured));
});
test('phone installation URL serves the exact delivered userscript without exposing credentials',async t=>{
  const dir=await fs.mkdtemp(path.join(decodeURIComponent(testTemp.pathname),'chasm-install-test-'));
  const {server,bridge}=await createServer({dir});await new Promise(r=>server.listen(0,'127.0.0.1',r));
  t.after(async()=>{bridge.close();server.closeAllConnections();await new Promise(r=>server.close(r));await fs.rm(dir,{recursive:true,force:true});});
  const base='http://127.0.0.1:'+server.address().port;
  const response=await fetch(base+'/chasm-ignitor-gpt.user.js');assert.equal(response.status,200);assert.equal(await response.text(),script);
  const page=await(await fetch(base+'/')).text();assert.ok(page.includes('/chasm-ignitor-gpt.user.js'));assert.ok(!page.includes(bridge.auth.identity.pair));
});
