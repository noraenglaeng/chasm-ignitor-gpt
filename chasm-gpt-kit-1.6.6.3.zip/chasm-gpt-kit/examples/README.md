이 폴더의 tampermonkey-client.js는 첨부 공통 연결 자료의 원문 예제입니다.
독립 사용자 스크립트로 설치하거나 현재 수정본에 추가로 붙이지 마세요.
실제로 배포하는 경로는 ../chasm-ignitor-gpt-1.6.6.3.user.js의 ChasmGPTClient입니다.
현재 수정본은 예제와 달리 Web Locks가 없으면 중단하며 완료된 요청 번호도 보관합니다.
